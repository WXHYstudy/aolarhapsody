import stylelintConfig from './internal/lint-configs/stylelint-config/index.mjs';

export default stylelintConfig;