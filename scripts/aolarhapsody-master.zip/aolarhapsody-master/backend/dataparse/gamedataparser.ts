import axios from 'axios';
import { getFromCache, saveToCache } from './file-cache';

/**
 * 安全地解析类似JavaScript对象的字符串
 * @param content - 要解析的字符串内容
 * @returns 解析后的对象或数组
 */
function safeParse(content: string) {
  try {
    return JSON.parse(content);
  } catch (error) {
    console.error('将字符串解析为JSON时出错:', error);
    throw new Error('无法将字符串解析为JSON请确保数据是有效的JSON格式');
  }
}

/**
 * 从JavaScript文件内容中提取并解析一个字典（对象）
 * @param jsContent - JavaScript文件的完整内容
 * @param dictionaryKey - 要提取的字典的键名（例如 'PMAttributeMap._skillAttributeData'）
 * @returns 解析后的字典数据
 */
export function extractDictionary(jsContent: string, dictionaryKey: string): unknown {
  const keyPath = dictionaryKey.replace(/\./g, '\\.');
  const regex = new RegExp(`${keyPath}\\s*=\\s*(\\[[\\s\\S]*?\\]);`);
  const match = jsContent.match(regex);

  if (match && match[1]) {
    let dataString = match[1];
    // 移除注释和多余的逗号
    dataString = dataString.replace(/\/\*[\s\S]*?\*\/|\/\/.*/g, '');
    dataString = dataString.replace(/,\s*]/g, ']');
    return safeParse(dataString);
  }

  throw new Error(`在JS内容中未找到键为 "${dictionaryKey}" 的字典`);
}

/**
 * 从给定的URL获取JS文件，并从中提取和解析一个字典
 * @param url - JavaScript文件的URL
 * @param dictionaryKey - 要提取的字典的键名
 * @returns 解析后的字典数据
 */
export async function fetchAndParseDictionary(
  url: string,
  dictionaryKey: string
): Promise<unknown> {
  const cachedData = await getFromCache<unknown>(url);
  if (cachedData) {
    return cachedData;
  }

  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
      },
    });

    if (response.status !== 200) {
      throw new Error(`HTTP错误: ${response.status} ${response.statusText}`);
    }

    const jsContent = response.data;
    const dictionary = extractDictionary(jsContent, dictionaryKey);
    await saveToCache(url, dictionary);
    return dictionary;
  } catch (error) {
    console.error(`获取或解析字典 "${dictionaryKey}" 时出错:`, error);
    throw error;
  }
}

/**
 * 从给定的URL获取并解析一个JSON文件
 * @param url - JSON文件的URL
 * @param truncate - 是否截断JSON只解析第一个条目
 * @returns 解析后的JSON数据
 */
export async function fetchAndParseJSON(url: string, truncate = false): Promise<unknown> {
  const cachedData = await getFromCache<unknown>(url);
  if (cachedData) {
    return cachedData;
  }

  try {
    const response = await axios.get(url, {
      responseType: 'text', // 获取原始文本响应
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
      },
    });

    if (response.status !== 200) {
      throw new Error(`HTTP错误: ${response.status} ${response.statusText}`);
    }

    const responseData = response.data;
    let parsedData: unknown;

    if (truncate && typeof responseData === 'string') {
      const firstBrace = responseData.indexOf('{');
      const firstComma = responseData.indexOf(',', firstBrace);
      if (firstBrace !== -1 && firstComma !== -1) {
        // 截取到第一个逗号，并补全右大括号
        const truncatedData = responseData.substring(firstBrace, firstComma) + '}';
        try {
          parsedData = JSON.parse(truncatedData);
        } catch (e) {
          console.error('解析截断后的数据时出错:', e);
          // 如果解析失败，则回退到解析完整数据
          parsedData = JSON.parse(responseData);
        }
      } else {
        parsedData = JSON.parse(responseData);
      }
    } else if (typeof responseData === 'string') {
      parsedData = JSON.parse(responseData);
    } else {
      parsedData = responseData;
    }

    await saveToCache(url, parsedData);
    return parsedData;
  } catch (error) {
    console.error(`获取或解析JSON时出错:`, error);
    throw error;
  }
}

/**
 * 从给定的URL获取并解析一个JSON文件，并将其转换为指定的类型
 * @param url - JSON文件的URL
 * @returns 解析后的类型化JSON数据
 */
export async function fetchAndParseData<T>(url: string, truncate = false): Promise<T> {
  const data = await fetchAndParseJSON(url, truncate);
  return data as T;
}

/**
 * 从给定的URL获取JavaScript文件内容
 * @param url - JavaScript文件的URL
 * @returns JavaScript文件的文本内容
 */
export async function fetchJavaScriptFile(url: string): Promise<string> {
  const cachedData = await getFromCache<string>(url);
  if (cachedData) {
    return cachedData;
  }

  try {
    const response = await axios.get(url, {
      headers: {
        'User-Agent':
          'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0 Safari/537.36',
      },
    });

    if (response.status !== 200) {
      throw new Error(`HTTP错误: ${response.status} ${response.statusText}`);
    }

    const jsContent = response.data;
    await saveToCache(url, jsContent);
    return jsContent;
  } catch (error) {
    console.error(`获取JavaScript文件时出错:`, error);
    throw error;
  }
}
