export interface ExistingActivity {
  name: string;
  packet: string;
}
