export interface DataItem {
  id: number | string;
  name: string;
  [key: string]: any;
}
