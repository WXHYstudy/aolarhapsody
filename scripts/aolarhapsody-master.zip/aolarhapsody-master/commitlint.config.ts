/**
 * Commitlint configuration.
 * Extends the conventional commit config.
 */
export default {
  extends: ['@commitlint/config-conventional']
};